<?php
session_start();



require_once 'google-api-php-client/src/Google/autoload.php';



/************************************************

  ATTENTION: Fill in these values! Make sure

  the redirect URI is to this page, e.g:

  http://localhost:8080/user-example.php

 ************************************************/

 $client_id = '649847755306-2dho7k7pge81pn8qdejopbb55hk9v3pk.apps.googleusercontent.com';

 $client_secret = '2pu9oFlKJNBg5xlRdkEh1Bq6';

 $redirect_uri = 'http://helixhouse.info/accounts.php';

try {

/************************************************

  Make an API request on behalf of a user. In

  this case we need to have a valid OAuth 2.0

  token for the user, so we need to send them

  through a login flow. To do this we need some

  information from our API console project.

 ************************************************/

$client = new Google_Client();

$client->setClientId($client_id);

$client->setClientSecret($client_secret);

$client->setRedirectUri($redirect_uri);

$client->addScope(Google_Service_Analytics::ANALYTICS_READONLY);



/************************************************

  When we create the service here, we pass the

  client to it. The client then queries the service

  for the required scopes, and uses that when

  generating the authentication URL later.

 ************************************************/

$analytics = new Google_Service_Analytics($client);





/************************************************

  If we have an access token, we can make

  requests, else we generate an authentication URL.

 ************************************************/

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {

  $client->setAccessToken($_SESSION['access_token']);

} else {

  $authUrl = $client->createAuthUrl();

}




// Query the API
function getResults(&$analytics, $profileId) {
	// Calls the Core Reporting API and queries the specified data
	$startDate = getStartDate();
  	$endDate = getEndDate(); 
	return $analytics->data_ga->get(
			'ga:' . $profileId,
			//'30daysAgo',
			$startDate,
			//'today',
			$endDate,
			'ga:users,ga:newUsers,ga:pageviews,ga:pageviewsPerSession');
}




function printResults(&$results) {
  // Parses the response from the Core Reporting API and prints
  // the profile name and total sessions.
  if (count($results->getRows()) > 0) {

    // Get the profile name.
    $profileName = $results->getProfileInfo()->getProfileName();

    // Get the entry for the first entry in the first row.
    $rows = $results->getRows();
    $user = $rows[0][0];
    $newUser = $rows[0][1];
    $oldUser = $user - $newUser;
    $pageView = $rows[0][2]; 
    $pagesPerVisit = round($rows[0][3],2); 
    // Print the results.
echo '
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
</head>
<body>

<table style="width:100%">
  <caption><b>USER INFO</b></caption> 
<tr>
    <td>Users</td>
    <td>',$user,'</td>
  </tr>
  <tr>
    <td>New Users</td>
    <td>', $newUser,'</td>
  </tr>
  <tr>
    <td>Returning Users</td>
    <td>',$oldUser,'</td>
  </tr>
  <tr>
    <td>Page Views</td>
    <td>',$pageView,'</td>
  </tr>
  <tr>
    <td>Pages / Visit</td>
    <td>',$pagesPerVisit,'</td>
  </tr>
</table>

</body>';


  } else {
    print "No results found.\n";
  }
}

$id = getProfileId();
$results = getResults($analytics, $id);
printResults($results);

} catch (Exception $e) {
	//echo 'Caught exception: ',  $e->getMessage(), "\n";
	echo '<meta http-equiv="refresh" content="0; URL=http://helixhouse.info/index.php">';
}

?>