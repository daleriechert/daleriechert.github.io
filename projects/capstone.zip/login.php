<?php
session_start();
include("dbconnect.php");
$con= new dbconnect();
$con->connect();


$sql = "SELECT user_id FROM User WHERE username = '".$_POST["login"]."' AND password = PASSWORD('".$_POST["password"]."')";

$result = mysql_query($sql);






//get the number of rows in the result set; should be 1 if a match
if (mysql_num_rows($result) == 1) {
 
      
         
         $_SESSION['status']=100; // indicate that the login is successful
        // echo "Login success, you will be directed to the  EventBook in 5 seconds";
         header("refresh: 2; url= tracking.php");
        
      
      
      }  else {
	//redirect back to login form if not authorized
	  //echo "incorrect login";
         header("refresh:2; url=index.html");

}
?>


