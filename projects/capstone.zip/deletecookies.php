<?php
	setcookie("_gat", "", time()-3600);
	setcookie("PHPSESSID", "", time()-3600);
	setcookie("_ga", "", time()-3600);
	header('Location: http://helixhouse.info/index.php');
?>