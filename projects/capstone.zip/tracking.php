<?php session_start();?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Helix House</title>
<link rel="shortcut icon" href="images/favicon.png">
<link href="style.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>
<!-- GA tracking -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-72153740-1', 'auto');
  ga('send', 'pageview');

</script>
</head>

<body class="body">

<?php
	$_SESSION["profileId"] = getProfileId();
	$_SESSION["phone"] = getPhone();
?>

<header class="header">
    	<div class="logo">
        	<img src="images/helix-house-logo-long_1603.png" height="50" alt="Helix House"/>
        </div>
        <div class="title">
            <div class="date" style="font-weight: 500;">
                <p><form action="tracking.php" method="get">
                	<!--Save the two values from previous page and add two new ones for the dates.-->
                    <input type="hidden" name="profileId" value="<?php echo getProfileId(); ?>">
                    <input type="hidden" name="phone" value="<?php echo getPhone(); ?>">
                    Start Date: 
                    <input type="date" name="startDate" value="<?php echo getStartDate(); ?>">
                    End Date:
                    <input type="date" name="endDate" value="<?php echo getEndDate(); ?>">
                    <button type-"submit">Submit</button>
                </form>
                </p>
            </div>
        </div>

        <div class="logout">
        	<p><a href="index.php">Logout</a></p>
        </div>
        
</header>

<div class="horizontal-box" id="audience-overview">
    <div class="content-box">
    	<input class="toggle-box" id="Audience Overview" type="checkbox" checked="checked">
		<label for="Audience Overview"><p><h3>Audience Overview</h3></p></label>
		<div><?php include 'audienceOverview.php'; ?></div>
    </div>
</div>
<div class="horizontal-box" id="acquisition-overview">
	<div class="content-box">
        <input class="toggle-box" id="Acquisition Overview" type="checkbox" checked="checked">
		<label for="Acquisition Overview"><p><h3>Acquisition Overview</h3></p></label>
		<div><?php include 'acquisitionOverview.php'; ?></div>
    </div>
</div>

<!--<div class="horizontal-box" id="google-ads">
	<div class="content-box">
        <input class="toggle-box" id="Google Ads" type="checkbox" checked="checked">
		<label for="Google Ads"><p><h3>Google Ads</h3></p></label>
		<div><!--API</div>
    </div>
</div>-->

<div class="vertical-box" id="cost-per-acquisition">
	<div class="content-box">
        <input class="toggle-box" id="Cost Per Acquisition" type="checkbox" checked="checked">
		<label for="Cost Per Acquisition"><p><h3>Paid Search Spend</h3></p></label>
        <div><?php include 'costPerAcquisition.php'; ?></div>
    </div>
</div>

<div class="vertical-box" id="roi">
	<div class="content-box">
        <input class="toggle-box" id="Return On Investment" type="checkbox" checked="checked">
		<label for="Return On Investment"><p><h3>Paid Search Breakdown</h3></p></label>
        <div><?php include 'roi.php'; ?></div>
    </div>
</div>

<div class="vertical-box" id="call-tracking">
	<div class="content-box">
        <input class="toggle-box" id="Call Tracking" type="checkbox" checked="checked">
		<label for="Call Tracking"><p><h3>Call Tracking</h3></p></label>        
        <?php include 'calltracking.php'; ?></div>
	</div>
</div>



</body>
</html>

<?php
	//Get values from URL
	
	function getStartDate() {
		if ($_GET["startDate"] == NULL) { //If no date entered, default to 30 days ago
			$startDate = date('Y-m-d', strtotime('-30 days'));
		}
		else $startDate = $_GET["startDate"];
		return $startDate;
	}
	
	function getEndDate() {
		if ($_GET["endDate"] == NULL) { //If no date entered, default to today
			$endDate = date('Y-m-d');
		}
		else $endDate = $_GET["endDate"];
		return $endDate;
	}
	
	function getPhone() {
		if ($_GET["phone"] == NULL) {
			return NULL; 
		}
		else $phone = $_GET["phone"];
		return $phone;
	}
	
	function getProfileId() {
		if ($_GET["profileId"] == NULL) {
			return NULL; 
		}
		else $profileId = $_GET["profileId"];
		return $profileId;
	}
?>
