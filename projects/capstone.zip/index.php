<?php session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Helix House</title>
<link rel="shortcut icon" href="images/favicon.png">
<link href="style.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Dosis:400,700" rel="stylesheet" type="text/css">
<!--GA tracking-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-72153740-1', 'auto');
  ga('send', 'pageview');
</script>

</head>

<body class="body">
<?php include_once("analyticstracking.php") ?>
<header class="header">
    	<div class="logo">
        	<img src="images/helix-house-logo-long_1603.png" height="50" alt="Helix House"/>
        </div>
        <div class="title">
          <p>Login</p>
        </div>
</header>

<div style="width: 50%;" class="vertical-box" id="login">
	<div class="content-box">
		<form action="tracking.php" method="get">
			<p>Google Profile ID: <br>
            <input type="text" name="profileId" placeholder="XXXXXXXXX" value="<?php echo $_SESSION["profileId"] ?>"><br>
			Phone Number: <br>
            <input type="tel" name="phone" placeholder="XXX XXX XXXX" value="<?php echo $_SESSION["phone"] ?>"><br>
			<button type="submit">Submit</button>
		</form>

        Google Analytics Profiles:<br>
        <?php
			//override redirect
			$redirect = 0;
			include 'accounts.php'; 
		?>
	</div>
</div>

</body>
</html>
