﻿<?php
// Get the PHP helper library from twilio.com/docs/php/install
require_once('twilio-php-master/Services/Twilio.php'); // Loads the library
 
// Your Account Sid and Auth Token from twilio.com/user/account
$sid = "REMOVED"; 
$token = "REMOVED"; 
$client = new Services_Twilio($sid, $token);

$phone = getPhone();
$startDate = getStartDate();
$endDate = date('Y-m-d', strtotime(getEndDate() .' +1 day')); //Advance one day to account for EndDate being at 12:00AM and not 11:59PM

$index = 0; //Call loop index number
$duration = array(); //Call durations
$thirty = 0; //Calls over 30 seconds
$sixty = 0; //Calls over 1 minute
$onetwenty = 0; //Calls over 2 minutes
$average = 0; //Call duration average

if ($phone == NULL) {
	//No phone number, return error message
	echo "<div style =\"color:red;\">No Phone Number</div>";
}

else if ($phone < 1000000000) {
	//Invalid phone number, return error message
	echo "<div style =\"color:red;\">Invalid Number<br>Format: XXX XXX XXXX</div>";
}

else {
	// Loop over the list of calls and perform functions for each one
	foreach ($client->account->calls->getIterator(0, 50, array(
		"Status" => "completed",
		"StartTime>" => $startDate,
		"StartTime<" => $endDate,
		"To" => "+1".$phone
		)) as $call ) {
			
		$duration[$index]=$call->duration; //Store call durations in array
		
		if ($call->duration > 30) {
			$thirty++;
			if ($call->duration > 60) {
				$sixty++;
				if ($call->duration > 120) {
					$onetwenty++;	
				}
			}
		}
	
		$index++;
	}
	
	echo '
	<style>
	table, th, td {
		border: 1px solid black;
		border-collapse: collapse;
	}
	th, td {
		padding: 5px;
		text-align: left;
	}
	</style>
	</head>
	<body>
	
	<table style="width:100%">
		<tr>
			<td>Total Calls</td>
			<td>',count($duration),'</td>
		</tr>
		<tr>
			<td>Over 30 Seconds</td>
			<td>',$thirty,'</td>
		</tr>
		<tr>
			<td>Over 1 Minute</td>
			<td>',$sixty,'</td>
		</tr>
		<tr>
			<td>Over 2 Minutes</td>
			<td>',$onetwenty,'</td>
		</tr>
		<tr>
			<td>Duration Average</td>
			<td>';
				foreach($duration as $value) {
					$average += $value;
				}
				if (count($duration) > 0) $average = $average / count($duration);
				$average = round($average);
				echo floor($average / 60),' minutes ',$average % 60,' seconds </td>
		</tr>
	</table>
	</body>';
}

?>