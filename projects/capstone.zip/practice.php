<?php

error_reporting(E_ERROR | E_PARSE);

/*

 * Copyright 2011 Google Inc.

 *

 * Licensed under the Apache License, Version 2.0 (the "License");

 * you may not use this file except in compliance with the License.

 * You may obtain a copy of the License at

 *

 *     http://www.apache.org/licenses/LICENSE-2.0

 *

 * Unless required by applicable law or agreed to in writing, software

 * distributed under the License is distributed on an "AS IS" BASIS,

 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

 * See the License for the specific language governing permissions and

 * limitations under the License.

 */



session_start();



require_once 'google-api-php-client/src/Google/autoload.php';



/************************************************

  ATTENTION: Fill in these values! Make sure

  the redirect URI is to this page, e.g:

  http://localhost:8080/user-example.php

 ************************************************/

 $client_id = '649847755306-2dho7k7pge81pn8qdejopbb55hk9v3pk.apps.googleusercontent.com';

 $client_secret = '2pu9oFlKJNBg5xlRdkEh1Bq6';

 $redirect_uri = 'http://helixhouse.info/accounts.php';



/************************************************

  Make an API request on behalf of a user. In

  this case we need to have a valid OAuth 2.0

  token for the user, so we need to send them

  through a login flow. To do this we need some

  information from our API console project.

 ************************************************/

$client = new Google_Client();

$client->setClientId($client_id);

$client->setClientSecret($client_secret);

$client->setRedirectUri($redirect_uri);

$client->addScope(Google_Service_Analytics::ANALYTICS_READONLY);

$client->setAccessType('offline');



/************************************************

  When we create the service here, we pass the

  client to it. The client then queries the service

  for the required scopes, and uses that when

  generating the authentication URL later.

 ************************************************/

$analytics = new Google_Service_Analytics($client);



/************************************************

  If we're logging out we just need to clear our

  local access token in this case

 ************************************************/

if (isset($_REQUEST['logout'])) {

  unset($_SESSION['access_token']);


}



/************************************************

  If we have a code back from the OAuth 2.0 flow,

  we need to exchange that with the authenticate()

  function. We store the resultant access token

  bundle in the session, and redirect to ourself.

 ************************************************/

if (isset($_GET['code'])) {

  $client->authenticate($_GET['code']);

  $_SESSION['access_token'] = $client->getAccessToken();

  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];

  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
$google_token= json_decode($_SESSION['access_token']);
$client->refreshToken($google_token->refresh_token);
$_SESSION['access_token']= $client->getAccessToken();

}



/************************************************

  If we have an access token, we can make

  requests, else we generate an authentication URL.

 ************************************************/

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {

  $client->setAccessToken($_SESSION['access_token']);

} else {

  $authUrl = $client->createAuthUrl();

}



/************************************************

  If we're signed in and have a request to shorten

  a URL, then we create a new URL object, set the

  unshortened URL, and call the 'insert' method on

  the 'url' resource. Note that we re-store the

  access_token bundle, just in case anything

  changed during the request - the main thing that

  might happen here is the access token itself is

  refreshed if the application has offline access.

 ************************************************/

function queryCoreReportingApi(&$analytics, $profileId) {
  
$optParams = array(
      'dimensions' => 'ga:medium',
      'max-results' => '25');
$startDate = getStartDate();
  	$endDate = getEndDate(); 
  return $analytics->data_ga->get(
      'ga:' . $profileId,
      $startDate,
      $endDate,
      'ga:sessions',
      $optParams);
}

 function printDataTable(&$results) {
  if (count($results->getRows()) > 0) {
    $rows = $results->getRows();
    $direct = $rows[0][1];
    $cpc = $rows[1][1];
    $org = $rows[2][1];
    $ref = $rows[3][1];
    $sessions = $direct + $cpc + $org + $ref;
    // Print the results.
   echo '
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
</head>
<body>

<table style="width:100%">
  <caption><b>SESSIONS</b></caption>
  <tr>
    <td>Sessions</td>
    <td>', $sessions, '</td>
  </tr>
 <tr>
    <td>Referral/Social</td>
    <td>', $ref, '</td>
  </tr>
  <tr>
    <td>Paid Search</td>
    <td>', $cpc, '</td>
  </tr>
  <tr>
    <td>Organic</td>
    <td>', $org, ' </td>
  </tr>
  <tr>
    <td>Direct</td>
    <td>', $direct, '</td>
  </tr>
</table>

</body>';

  } else {
    print "No results found.\n";
  }
}

function queryCoreReportingApi1(&$analytics, $profileId) {
 
$startDate = getStartDate();
	$endDate = getEndDate();
  return $analytics->data_ga->get(
      'ga:' . $profileId,
      $startDate,
      $endDate,
      'ga:bounceRate,ga:pageviewsPerSession,ga:avgSessionDuration,ga:goalConversionRateAll,ga:goalCompletionsAll,ga:goalValueAll');
}

function printDataTable1(&$results) {
  if (count($results->getRows()) > 0) {
    $rows = $results->getRows();
    $bounce = round($rows[0][0],2);
    $pageper = round($rows[0][1],2);
    $avg= $rows[0][2];
    $goalRate = $rows[0][3];
    $goalCompletion = $rows[0][4];
    $goalValue = $rows[0][5];
    // Print the results.
   echo '
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
</style>
</head>
<body>

<table style="width:100%">
 <caption><b>BEHAVIOR</b></caption> 
  <tr>
    <td>Bounce Rate</td>
    <td>', $bounce, '</td>
  </tr>
 <tr>
    <td>Page / Session</td>
    <td>', $pageper, '</td>
  </tr>
  <tr>
    <td>Average Session Duration</td>
    <td>', floor($avg / 60),' minutes ',$avg % 60,' seconds </td>  </tr>

</table>
<table style="width:100%">
  <caption><b>CONVERSIONS</b></caption>
  <tr>
    <td>Goal Conversion Rate</td>
    <td>', $goalRate, '</td>
  </tr>
  <tr>
    <td>Goal Completion</td>
    <td>', $goalCompletion, '</td>
  </tr>
  <tr>
    <td>Goal Value</td>
    <td>', $goalValue, '</td>
  </tr>
</table>


</body>';

  } else {
    print "No results found.\n";
  }
}
$id = getProfileId();
$results = queryCoreReportingApi($analytics, $id);
$results1 = queryCoreReportingApi1($analytics, $id);
printDataTable($results);
printDataTable1($results1);
?>
