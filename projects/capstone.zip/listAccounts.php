<?php

function getService1()
{
  // Creates and returns the Analytics service object.

  // Load the Google API PHP Client Library.
  require_once 'google-api-php-client/src/Google/autoload.php';

  // Use the developers console and replace the values with your
  // service account email, and relative location of your key file.
  $service_account_email = 'realaccount@t-tide-113416.iam.gserviceaccount.com'; //getServiceAccount()
  //$key_file_location = '../client_secrets2.p12';

  // Create and configure a new client object.
  $client = new Google_Client();
  $client->setApplicationName("HelloAnalytics");
  $analytics = new Google_Service_Analytics($client);

  // Read the generated client_secrets.p12 key.
  $key = file_get_contents('/home/hinfo/public_html/client_secrets2.p12');
	  $cred = new Google_Auth_AssertionCredentials(
      $service_account_email,
      array(Google_Service_Analytics::ANALYTICS_READONLY),
      $key
  );
  $client->setAssertionCredentials($cred);
  if($client->getAuth()->isAccessTokenExpired()) {
    $client->getAuth()->refreshTokenWithAssertion($cred);
  }

  return $analytics;
}

$analytics = getService1();

$result = $analytics->management_accounts->listManagementAccounts();
$accounts = $result->items;
foreach ($accounts as $account) {
    print "Found an account with an ID of {$account->id} and a name of {$account->name}<br>"; 
}

//Accounts: list
try {
  $accounts = $analytics->management_accounts->listManagementAccounts();
} catch (apiServiceException $e) {
  echo 'There was an Analytics API service error '
      . $e->getCode() . ':' . $e->getMessage() . '<br>';

} catch (apiException $e) {
  echo 'There was a general API error '
      . $e->getCode() . ':' . $e->getMessage() . '<br>';
}

echo "Accounts: " . count($accounts->getItems()) . "<br>";

foreach ($accounts->getItems() as $account) {
  $html = <<<HTML
<pre>
Account id   = {$account->getId()}
Account name = {$account->getName()}
Created      = {$account->getCreated()}
Updated      = {$account->getUpdated()}
</pre>
HTML;
  print $html;
}

//Account Summaries: list
try {
  $accounts = $analytics->management_accountSummaries
      ->listManagementAccountSummaries();
} catch (apiServiceException $e) {
  echo 'There was an Analytics API service error '
        . $e->getCode() . ':' . $e->getMessage() . '<br>';

} catch (apiException $e) {
  echo 'There was a general API error '
      . $e->getCode() . ':' . $e->getMessage() . '<br>';
}

echo "Accounts: " . count($accounts->getItems()) . "<br>";

foreach ($accounts->getItems() as $account) {
  $html = <<<HTML
<pre>
Account id   = {$account->getId()}
Account kind = {$account->getKind()}
Account name = {$account->getName()}
HTML;

  // Iterate through each Property.
  foreach ($account->getWebProperties() as $property) {
    $html .= <<<HTML
Property id          = {$property->getId()}
Property kind        = {$property->getKind()}
Property name        = {$property->getName()}
Internal property id = {$property->getInternalWebPropertyId()}
Property level       = {$property->getLevel()}
Property URL         = {$property->getWebsiteUrl()}
HTML;

    // Iterate through each view (profile).
    foreach ($property->getProfiles() as $profile) {
      $html .= <<<HTML
Profile id   = {$profile->getId()}
Profile kind = {$profile->getKind()}
Profile name = {$profile->getName()}
Profile type = {$profile->getType()}
HTML;
    }
  }
  $html .= '</pre>';
  print $html;
}


?>