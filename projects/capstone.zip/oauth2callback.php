<?php
session_start();



require_once 'google-api-php-client/src/Google/autoload.php';



/************************************************

  ATTENTION: Fill in these values! Make sure

  the redirect URI is to this page, e.g:

  http://localhost:8080/user-example.php

 ************************************************/

 $client_id = '649847755306-2dho7k7pge81pn8qdejopbb55hk9v3pk.apps.googleusercontent.com';

 $client_secret = '2pu9oFlKJNBg5xlRdkEh1Bq6';

 $redirect_uri = 'http://helixhouse.info/accounts.php';



/************************************************

  Make an API request on behalf of a user. In

  this case we need to have a valid OAuth 2.0

  token for the user, so we need to send them

  through a login flow. To do this we need some

  information from our API console project.

 ************************************************/

$client = new Google_Client();

$client->setClientId($client_id);

$client->setClientSecret($client_secret);

$client->setRedirectUri($redirect_uri);

$client->addScope(Google_Service_Analytics::ANALYTICS_READONLY);



/************************************************

  When we create the service here, we pass the

  client to it. The client then queries the service

  for the required scopes, and uses that when

  generating the authentication URL later.

 ************************************************/

$analytics = new Google_Service_Analytics($client);





/************************************************

  If we have an access token, we can make

  requests, else we generate an authentication URL.

 ************************************************/

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {

  $client->setAccessToken($_SESSION['access_token']);

} else {

  $authUrl = $client->createAuthUrl();

}

 function queryCoreReportingApi(&$analytics, $profileId) {
  $optParams = array(
      'dimensions' => 'ga:source,ga:keyword',
      'sort' => '-ga:sessions,ga:source',
      'filters' => 'ga:medium==organic',
      'max-results' => '25');

  return $analytics->data_ga->get(
      'ga:' . $profileId,
      '2016-03-24',
      '2016-04-24',
      'ga:sessions',
      $optParams);
}
$id = 114460017;
try {
    $results = queryCoreReportingApi($analytics, $id);
    // Success. Do something cool!

  } catch (apiServiceException $e) {
    // Handle API service exceptions.
    $error = $e->getMessage();
  }

 function printColumnHeaders($results) {
  $html = '';
  $headers = $results->getColumnHeaders();

  foreach ($headers as $header) {
    $html .= <<<HTML
Column Name = {$header->getName()}
Column Type = {$header->getColumnType()}
Column Data Type = {$header->getDataType()}
HTML;

  print $html;
}
}
printColumnHeaders(&results)
?>

