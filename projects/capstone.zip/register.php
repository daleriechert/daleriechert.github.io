<?php
include("dbconnect.php");
$con=new dbconnect();
$con->connect();
if(isset($_POST['submit'])) {
      // $type=10;

        
	$userSql = "INSERT INTO User 
		 ( username, password, first_name, last_name, company_name, email)
		 VALUES ('$_POST[username]', PASSWORD(\"$_POST[password]\"), '$_POST[first_name]', '$_POST[last_name]','$_POST[company_name]', '$_POST[email]')";
	$aSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '0', '$_POST[ga_login]', PASSWORD(\"$_POST[ga_password]\"))";
	$bSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '1', '$_POST[gaw_login]', PASSWORD(\"$_POST[gaw_password]\"))";
	$cSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '2', '$_POST[ba_login]', PASSWORD(\"$_POST[ba_password]\"))";
	$dSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '3', '$_POST[ct_login]', PASSWORD(\"$_POST[ct_password]\"))";
	$eSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '4', '$_POST[hs_login]', PASSWORD(\"$_POST[hs_password]\"))";
	$fSql = "INSERT INTO Login 
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '5', '$_POST[pr_login]', PASSWORD(\"$_POST[pr_password]\"))";
	$gSql = "INSERT INTO Login
		 (  username, api_id, api_u_name, api_pass)
		 VALUES ('$_POST[username]', '6', '$_POST[aw_login]', PASSWORD(\"$_POST[aw_password]\"))";


	mysql_query($userSql);
	mysql_query($aSql);
	mysql_query($bSql);
	mysql_query($cSql);
	mysql_query($dSql);
	mysql_query($eSql);
	mysql_query($fSql);
	mysql_query($gSql);

	echo '<h2>USER REGISRERED</h2><br />';
	

}
?>
<p><a href="index.html">Login</a></p>