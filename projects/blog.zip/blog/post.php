<?php

include("dbconnect.php");
$con= new dbconnect();
$con->connect();

if(isset($_POST['submit'])) {

	$sSql = "INSERT INTO posts (title, content)

		 VALUES ('".$_POST['title']."', '".$_POST['content']."')";

	mysql_query($sSql);

	echo " Post successful! You will be directed to the main page...";
	header("refresh: 1; index.php");
}

?>