<!DOCTYPE html>

<html>


<head>
<title>Blog</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<style type="text/css">
</style>
</head>

<body style="body">
<div id="container">

<div id="header">
<h1>Edit</h1>
</div>

<div id="section" style="text-align:center;">

<?php

include("dbconnect.php");
$con= new dbconnect();
$con->connect();

$id = $_POST['id'];

if(isset($_POST['submitedit'])) {
	$title = $_POST['title'];
	$content = $_POST['content'];         
	$sSql="UPDATE posts SET title =\"$title\" , content =\"$content\" WHERE postID =\"$id\"";
	mysql_query($sSql);
	echo " Edit successful! You will be directed to the main page...";
	header("refresh: 1; index.php");

}


if(isset($_POST['id'])) {

        $sSql = "SELECT * FROM posts WHERE postID=$id";

        $oResult = mysql_query($sSql);

        $aRow = mysql_fetch_assoc($oResult);
}
?>

<form method="post" action="update.php">

Title:<input type="text" name="title" value="<?php echo $aRow['title']; ?>"><br>

<textarea name="content" cols="50" rows="20"><?php echo $aRow['content']; ?></textarea><br>

<input type="hidden" name="id" value="<?php echo $_POST['id'] ?>">

<input type="submit" name="submitedit" value="Submit"><br>
<a href="index.php">Back</a>
</form>

</div>
<div id="footer">
CPI 310: Fall 2014<br>&copy; Dale Riechert
</div>

</div>
</body>
</html>