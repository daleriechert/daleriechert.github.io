<?php
class dbconnect {
	function connect() {
		$con=mysql_connect("localhost","user","password"); /* Info removed */
		if (!$con)
			die('Could not connect: ' . mysql_error());
		$sel=mysql_select_db("database", $con);  /* Info removed */
		if (!$sel)
			die ('Can\'t use database : ' . mysql_error());
	}
}
?>