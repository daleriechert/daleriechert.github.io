﻿<html>

<head>
<title>Blog</title>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
</style>
</head>

<body style="body">
<div id="container">

<div id="header">
<h1>Blog</h1>
</div>

<div id="section">

<?php
include("dbconnect.php");
$con= new dbconnect();
$con->connect();
error_reporting(E_ALL);
session_start();

echo "<div id=\"nav\"><a href=\"login.html\">Login</a>";
if ($_SESSION['type']==1) echo " - <a href=\"post.html\">Post</a>";

echo "</div>";

$numposts = mysql_fetch_array(mysql_query("SELECT MAX(postID) FROM posts"));
$postindex = $numposts[0];
for ($postindex; $postindex > 0; $postindex--){
	if (mysql_num_rows(mysql_query("SELECT * FROM posts WHERE postID='$postindex'")) >= 1){
	$post = mysql_query("SELECT * FROM posts WHERE postID='$postindex'");
		while($postarray = mysql_fetch_array($post)){
			echo "<div id=\"post\">"
			. "<h3>".$postarray[1]."</h3><br>"
			. $postarray[2];
			if ($_SESSION['type']==1) {
			echo "<form method=\"post\" action =\"update.php\">"
			. "<input type=\"hidden\" name=\"id\" value=\"$postindex\">"
			. "<input type=\"submit\" name=\"edit\" value=\"Edit\"></form>";
			echo "<form method=\"post\" action =\"delete.php\">"
			. "<input type=\"hidden\" name=\"type\" value=\"post\">"
			. "<input type=\"hidden\" name=\"id\" value=\"$postindex\">"
			. "<input type=\"submit\" name=\"delete\" value=\"Delete\"></form>";
			}
			echo "</div><br>";
		}
	}
	$numcomments = mysql_fetch_array(mysql_query("SELECT MAX(commentID) FROM comments"));
	$totalcomments = $numcomments[0];
	for ($commentindex = 1; $commentindex <= $totalcomments; $commentindex++){
		if (mysql_num_rows(mysql_query("SELECT * FROM posts WHERE postID='$postindex'")) >= 1){
			$comment = mysql_query("SELECT * FROM comments WHERE postID='$postindex' AND commentID='$commentindex'");
			while($commentarray = mysql_fetch_array($comment)){
				echo "<div id=\"comment\">"
				. $commentarray[2];
				if ($_SESSION['type']==1) echo "<br><form method=\"post\" action =\"delete.php\">"
									  	  . "<input type=\"hidden\" name=\"type\" value=\"comment\">"
									  	  . "<input type=\"hidden\" name=\"id\" value=\"$commentindex\">"
									  	  . "<input type=\"submit\" name=\"delete\" value=\"Delete\"></form>";
				echo "</div><br>";
			}
		}
	}
	if (mysql_num_rows(mysql_query("SELECT * FROM posts WHERE postID='$postindex'")) >= 1){
		echo "<div id=\"comment\"><form method=\"post\" action =\"comment.php\">"
		. "<textarea name=\"content\" cols=\"30\" rows=\"4\"></textarea><br>"
		. "<input type=\"hidden\" name=\"post\" value=\"$postindex\">"
		. "<input type=\"submit\" name=\"submit\" value=\"Post Comment\"></form></div><br>";
	}
}


?>

</div>




<div id="footer">
CPI 310: Fall 2014<br>&copy; Dale Riechert
</div>

</div>
</body>
</html>