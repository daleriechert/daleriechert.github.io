<?php
include("dbconnect.php");
$con = new dbconnect();
$con->connect();
session_start();

$username=$_POST['username'];

$password=$_POST['password'];

$query=mysql_query("SELECT * FROM users WHERE username='$username' and password='$password'");
if (mysql_num_rows($query) == 1) {
	$_SESSION['username']=$username;
	while ($row = mysql_fetch_array($query)) {
			$type =$row['type'];
	}
	$_SESSION['type']=$type;
	echo " Login successful! You will be directed to the main page...";
	header("refresh: 1; index.php");
}
else {
	echo "Invalid username or password...";
	header("refresh: 3; login.php");
}

?>

