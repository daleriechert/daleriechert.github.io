<?php

include("dbconnect.php");
$con= new dbconnect();
$con->connect();

if(isset($_POST['delete'])) {

	if ($_POST['type']=="post") {
		$id = $_POST['id'];
		$sSql = "DELETE FROM posts WHERE postID=\"$id\"";
		$oResult = mysql_query($sSql);
		$sSql = "DELETE FROM comments WHERE postID=\"$id\"";
		$oResult = mysql_query($sSql);
		echo " Delete successful. You will be directed to the main page...";
		header("refresh: 1; index.php");
	}
	else if ($_POST['type']=="comment") {
		$id = $_POST['id'];
		$sSql = "DELETE FROM comments WHERE commentID=\"$id\"";
		$oResult = mysql_query($sSql);
		echo " Delete successful. You will be directed to the main page...";
		header("refresh: 1; index.php");
	}
}

?>