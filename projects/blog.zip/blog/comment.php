<?php

include("dbconnect.php");
$con= new dbconnect();
$con->connect();

if(isset($_POST['submit'])) {
	if($_POST['content'] != NULL){
		$sSql = "INSERT INTO comments (postID, content)
	
			 VALUES ('".$_POST['post']."', '".$_POST['content']."')";
	
		mysql_query($sSql);
	
		echo " Comment successful! You will be directed to the main page...";
		header("refresh: 1; index.php");
	}
	else {
		echo " You must type a comment.";
		header("refresh: 1; index.php");
	}
}
?>